for v in range(len(self.dots)):
    self.canvas.delete(self.dots[v])

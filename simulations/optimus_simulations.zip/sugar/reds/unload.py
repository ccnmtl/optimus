for d in self.canvas_dots:
    self.canvas.delete(d)


data = self.csv2numeric(self.filename,(int,int,float))

self.x = data['x']
self.y = data['y']
self.emission = data['emission']

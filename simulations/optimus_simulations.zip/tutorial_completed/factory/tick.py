
self.organizer.generate_event(OptimusEvent("emit_pollution",
                                           {'x' : self.x,
                                            'y' : self.y,
                                            'pollution' : self.emission}))


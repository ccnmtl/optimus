for v in range(self.number):
    self.canvas.delete(self.dots[v])

for s in self.drawn_segments:
    self.canvas.delete(s)

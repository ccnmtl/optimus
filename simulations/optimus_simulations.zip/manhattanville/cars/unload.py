for c in self.cars:
    car = self.cars[c]
    self.canvas.delete(car.representation)

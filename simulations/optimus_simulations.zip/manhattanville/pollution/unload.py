self.canvas.delete(self.canvas_image)
